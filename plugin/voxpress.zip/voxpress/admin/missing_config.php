<div class="wrap">

     <h2><?php echo __("The Ubivox plugin is not configured yet", "voxpresss") ?></h2>

     <p>
         <a href="<?php echo admin_url("/admin.php?page=voxpress-options"); ?>"><?php echo __("Configure the Ubivox plugin", "voxpress") ?></a>
     </p>

</div>